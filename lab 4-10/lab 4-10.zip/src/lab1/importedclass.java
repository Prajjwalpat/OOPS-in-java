package lab1;

import lab.lab4;
public class importedclass {

	public static void main(String[] args) {
		lab4 l4 = new lab4();

	}

}
